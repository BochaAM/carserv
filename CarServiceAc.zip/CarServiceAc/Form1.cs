﻿using System.Data.SqlClient;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarServiceAc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkConnectionButton_Click(object sender, EventArgs e)
        {
            // Объявляем объект подключения. using гарантирует, что соединение будет закрыто,
            // даже если возникнет ошибка.
            SqlConnection connection = null;

            try
            {
                // Получаем строку подключения из файла App.config по имени "AutoServiceConnection".
                // Свойство ConnectionString класса ConfigurationManager.ConnectionStrings возвращает 
                // параметры для подключения.
                string connectionString = ConfigurationManager.ConnectionStrings["AutoServiceConnection"].ConnectionString;

                // Создаем экземпляр класса SqlConnection, передавая ему строку подключения в конструктор.
                // Конструктор SqlConnection инициализирует новый объект для связи с базой данных.
                connection = new SqlConnection(connectionString);

                // Метод Open() открывает соединение с базой данных с настройками,
                // указанными в строке подключения.
                connection.Open();

                // Свойство State объекта SqlConnection показывает текущее состояние соединения.
                // Если оно равно ConnectionState.Open, значит, мы успешно подключились.
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    // Выводим сообщение об успехе в метку на форме.
                    statusLabel.Text = "Статус: Подключение успешно установлено!";
                    statusLabel.ForeColor = System.Drawing.Color.Green;
                }
            }
            catch (Exception ex)
            {
                // Если на любом из этапов в блоке try возникла ошибка (например, неверная строка подключения),
                // мы попадаем в блок catch.
                // Выводим сообщение об ошибке.
                statusLabel.Text = "Статус: Ошибка подключения!";
                statusLabel.ForeColor = System.Drawing.Color.Red;
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка подключения", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Блок finally выполняется всегда, независимо от того, была ошибка или нет.
                // Проверяем, что соединение было создано и оно все еще открыто.
                if (connection != null && connection.State == System.Data.ConnectionState.Open)
                {
                    // Метод Close() закрывает соединение с базой данных.
                    // Крайне важно всегда закрывать соединения для освобождения ресурсов сервера.
                    connection.Close();
                }
            }
        }
    }
}
